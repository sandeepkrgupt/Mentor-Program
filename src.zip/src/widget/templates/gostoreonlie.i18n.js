import {defineMessages} from 'react-intl';

export default defineMessages({
    productHeaderTitle: {
        id: "productHeaderTitle",
        defaultMessage: "This is Header"
    }
})