import React from 'react';

const Slider = () => {
    return(
        <div>
            <h1>This container is for offer/product Sliders</h1>
        </div>
    );
}

export default Slider;