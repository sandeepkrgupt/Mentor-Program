import React, {Component} from 'react';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';

class TodoList extends Component {
    state = {
        Product: {
            MobileName : 'MI',
            MobilePrice: '29000'    
        }
    }

     AddPdtEntry = () => {
        this.setState({
            Product: this.state.Product
        })
    }
    render() {
        return(
            <div>
                <form onSubmit={this.addData} ref={form1}> 
                    <TextField label="Enter Mobile Name" id="txtMobName" fullWidth color="inherit" ref="MobName"/>
                    <TextField label="Enter Mobile Price" id="txtMobPrice" fullWidth color="inherit" ref="MobPrice" />
                    <Button type="submit" > Add</Button>
                </form>
                <table>
                    <thead>
                        <th>Mobile Name</th><th>Mobile Price</th>
                    </thead>
                    <tbody>
                        <tr>
                            <td>{this.state.MobileName}</td>
                            <td>{this.state.MobilePrice}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        );
    }
}

const MobileList = () => {
        return(
            <div>
                <table>
                    <tbody>
                        <tr>
                            {Object.keys(this.props.Product).map(function(key){
                                return (<td>{this.props.Product[key]}</td>);
                            }.bind(this))
                            }
                        </tr>
                    </tbody>
                </table>
            </div>
        );
}

const AddMobileToList = () => {
    addData = (e) => {
        e.preventDefault;
        const MobList = this.refs.MobName.value;
        if(typeof(MobList) === 'string' && MobList.length >0) {
            this.props.addData(MobList);
            this.refs.form1.reset();
        }
    }
}

export default TodoList;