import React from 'react';
import ProductLists from './comp-products';
import ProductCarousel from './comp-product-carousel';
import BannerSlider from './comp-carousel-slider';

const ProductContainer = () => {
    return(
        <div>
            <BannerSlider />
            <ProductCarousel />
            <ProductLists />
            <h1>Product Container</h1>
        </div>
    );
}

export default ProductContainer;