import React from 'react';
import ProductLists from './comp-products';

const ProductContainer = () => {
    return(
        <div>
            <h1>Product Container</h1>
            <ProductLists />
        </div>
    );
}

export default ProductContainer;