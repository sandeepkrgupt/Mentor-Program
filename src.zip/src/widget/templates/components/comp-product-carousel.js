import React from 'react';

const ProductCarousel = () => {
    return(
        <div>
            <h1>This is Product list Carousel</h1>
        </div>
    );
}

export default ProductCarousel;