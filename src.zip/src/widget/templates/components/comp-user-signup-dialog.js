import React from 'react';

const UserSignUpDialog = () => {
    return(
        <div>
            <h1>Use Login Dialog</h1>
        </div>
    );
}

export default UserSignUpDialog;