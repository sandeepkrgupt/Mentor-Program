import React from 'react';

const SideNav = () => {
    return(
        <div>
            <h2>Side Navigation</h2>
            <ul>
                <li>Mobiles</li>
                <li>Laptops</li>
                <li>Desktops</li>
                <li>Men Wears</li>
                <li>Women Wears</li>
            </ul>
        </div>
    );
}

export default SideNav;