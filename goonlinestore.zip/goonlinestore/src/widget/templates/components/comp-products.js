import React, {Component} from 'react';

class ProductLists extends Component {
    state = {
        price : '10000',
        availability: 'In Stock',
        colors: ["red","blue","black","grey"]
    }
    render() {
        return(
            <div>
                <div>
                    <img/>
                </div>
                <div>
                    Price :{this.state.price}
                    Availability : {this.state.availability}
                    Colors : {this.state.colors}
                </div>
            </div>
        );
    }
}

export default ProductLists;
